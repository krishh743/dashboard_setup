import React from 'react'

function TestPage() {
  return (
    <div>
      test page Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptas a suscipit quam quas qui, vitae quidem aut voluptates error tenetur hic quis debitis iste quos repellendus incidunt temporibus. Fugit, nesciunt?
    </div>
  )
}

export default TestPage

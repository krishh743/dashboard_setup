import React from 'react'

function Dashboard() {
  return (
    <div>
      dashboard Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut temporibus nobis facilis rem fuga pariatur eius autem quae laboriosam soluta accusamus hic iste dicta voluptates ex nihil, odit ullam fugiat!
    </div>
  )
}

export default Dashboard
